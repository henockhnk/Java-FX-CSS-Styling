
package web_v007;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.beans.binding.Bindings;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Web_v007 extends Application 
{

    public static void main(String[] args) 
    {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception 
    {
        
        Label lb1 = new Label("New Amazing Cars");
        lb1.setStyle("-fx-font-size: 35px;");
                
        Label lb2 = new Label("is ");
        lb2.setStyle("-fx-font-size: 35px;");
        
        Label lb10 = new Label("Unique ");
        lb10.setStyle("-fx-font-size: 35px; -fx-text-fill: #E87094; -fx-font-weight: bold;");
        
        Separator sprtr1 = new Separator(Orientation.VERTICAL);
        sprtr1 . setMaxWidth(2);
        
        
        HBox hb10 = new HBox();
        hb10.getChildren().addAll(lb2, lb10);
        
        HBox hb11 = new HBox();
        hb11.getChildren().addAll(hb10, sprtr1);
        
        VBox vb0 = new VBox();
        vb0.getChildren().addAll(lb1, hb11);
        vb0.setAlignment(Pos.CENTER_LEFT);
        
        Label lb3 = new Label("Clear your mind with java-FX and CSS Styling");
        Label lb4 = new Label("in order to upgrade it without making it big");
        Label lb5 = new Label("and many more to come.");
        
        VBox vb1 = new VBox();
        vb1.getChildren().addAll(lb3, lb4, lb5);
        vb1.setAlignment(Pos.CENTER_LEFT);
        
        Button btn0 = new Button("Buy Now");
        btn0.styleProperty().bind(Bindings.when(btn0.hoverProperty()).then("-fx-background-color: #BD5B78; -fx-font-size: 20px; -fx-text-fill: white;").otherwise("-fx-background-color: #E87094; -fx-font-size: 20px; -fx-text-fill: white;")); 
        
        Button btn1 = new Button("View Demo");
        btn1.styleProperty().bind(Bindings.when(btn1.hoverProperty()).then("-fx-background-color: #4A4A52; -fx-font-size: 20px; -fx-text-fill: white;").otherwise("-fx-background-color: #656670; -fx-font-size: 20px; -fx-text-fill: white;")); 
        
        HBox hb0 = new HBox(15);
        hb0.getChildren().addAll(btn0, btn1);
        hb0.setAlignment(Pos.CENTER_LEFT);
        
        VBox vb2 = new VBox(22);
        vb2.getChildren().addAll(vb0, vb1, hb0);
        
        Image img1= new Image("./aa/a (51).jpg");
        ImageView imageView1 = new ImageView(img1);
        imageView1.setFitHeight(140);
        imageView1.setFitWidth(230);
        
        
        //Background Image
        Image img10 = new Image("./aa/a (41).jpg");
     
        BackgroundImage bgImage1 = new BackgroundImage
        (
            img10, 
            BackgroundRepeat.NO_REPEAT,
            BackgroundRepeat.NO_REPEAT,
            BackgroundPosition.CENTER,
            new BackgroundSize(100,100,true,true,true,true)
        );

        Background bg1 = new Background(bgImage1); 
        
        VBox vb12 = new VBox();
        vb12.getChildren().addAll(imageView1);
        vb12.setPadding(new Insets(60, 0, 20, 20));
        
        HBox hb1 = new HBox(30);
        hb1.getChildren().addAll(vb2, vb12);
        
        
        
        BorderPane bp = new BorderPane();
        bp.setCenter(hb1);
        bp.setPadding(new Insets(20, 20, 20, 20));
        bp.setBackground(bg1);
        
        Scene sc = new Scene(bp, 630, 300);
        
        
        //logo
        Image icon = new Image("./aa/a (163).jpg");      
        primaryStage.getIcons().add(icon);
        
        primaryStage.setScene(sc);
        primaryStage.show();
        primaryStage.setTitle("htttps://www.web7.com/");
    }
    
}
